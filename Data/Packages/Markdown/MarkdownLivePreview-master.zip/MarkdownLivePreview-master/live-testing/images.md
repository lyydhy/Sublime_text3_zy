I'm not sure that it **actually** going to work, but it seems nicer than the [previous version][prev]

this is a test, hello world

This is the first image from the local file system (absolute path, sorry, it's not going
to work on your system unless your username is math2001):

![The sublime text logo!](file:///home/math2001/.config/sublime-text-3/Packages/MarkdownLivePreview/live-testing/sublime_text.png)

This is the first image from the local file system, *relative* path!

![The sublime text logo!](sublime_merge.png)

This is the first image from the internet!

![math2001's logo](https://avatars1.githubusercontent.com/u/15224242?s=400&u=53324cf4e303d15032ba53aa41673a2046b3284b&v=4)

[prev]: https://github.com/math2001/MarkdownLivePreview/tree/d4c477749ce7e77b8e9fc85464a2488f003c45bc